Charlene Mundel

[Live Sketch Link] (https://yewtreedesign.github.io/120-work/hw-11/)

Okay Here's some penguins and a bag of cool ranch doritos.

What I want to do is have the penguins follow the bag of doritos.
Or if you click, a dorito chip would appear where you clicked with the bag dorito.

I am working with array of images. and different functions.
